# Интерфейс справочника
while True:
    choise = int(input('Выберите действие:\n 1 - Добавить данные в справочник\n 2 - Вывести весь справочник\n 3 - Поиск\n '
                       '4 - Изменить данные\n 5 - Удалить из справочника\n 6 - Выход\n'))
    match choise:
        case 1:
            import input1
            input1.Input(input('Введите фамилию: '), input('Введите имя: '), input('Введите номер: '))
        case 2:
            from output import OutputAll
            OutputAll()
        case 3:
            from output import Search
            Search(input('Введите фамилию или номер: '))
        case 4:
            import change
            change.Change(input('Введите что нужно изменить: '), input('Введите измененные данные: '))
        case 5:
            import delete
            delete.Delete(input('Введите удаляемое имя или номер: '))
        case 6:
            print('Спасибо за пользование!')
            break
        case _:
            print('\nВыберите один из указанных вариантов\n')