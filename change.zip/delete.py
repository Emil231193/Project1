# Удаление элемента
def Delete(data):
    with open('file.txt', encoding='utf-8') as infile, open('file1.txt', "w", encoding='utf-8') as outfile:
        for line in infile:
            if data.lower() not in line.lower():
                outfile.write(line)
    import os
    os.remove('file.txt')
    os.rename('file1.txt', 'file.txt')
    print('\nУдалено успешно\n')