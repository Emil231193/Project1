# Ввод данных в справочник
def Input(second_name, name, number):
    with open('file.txt', 'a', encoding = 'utf-8') as file:
        file.write(f'{second_name} {name} : {number}\n')
    print('\nДобавлено успешно\n')