# Поиск всех/поиск по фамилии
def OutputAll():
    with open('file.txt', 'r', encoding='utf-8') as file:
        for line in file:
            print(line)

def Search(data):
    with open('file.txt', 'r', encoding='utf-8') as file:
        flag = False
        for line in file:
            if data.lower() in line.lower():
                print(line)
                flag = True
        if flag == False:
            print('\nДанных не найдено\n')